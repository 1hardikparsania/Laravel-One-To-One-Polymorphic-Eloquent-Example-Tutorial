<html>
<head>
   
</head>
<style>
 
 
</style>
 
<h1> Laravel One to One Polymorphic Example </h1>
 
<h3> First Team Goal </h3>
 
<li> 
    <?php echo e($goalFirstTeam->goal_body); ?>  
</li>

<h3> First Player Goal </h3>

<li> 
    <?php echo e($goalFirstPlayer->goal_body); ?>  
</li>

<h3> Second Team Goal </h3>
 
<li> 
    <?php echo e($goalSecondTeam->goal_body); ?>  
</li>
 
 
</body>
</html><?php /**PATH /Users/hardikparsania_mac/Desktop/web_demonuts/laraonetoonepoly/laraonetoonepolym/resources/views/index.blade.php ENDPATH**/ ?>
<html>
<head>
   
</head>
<style>
 
 
</style>
 
<h1> Laravel One to One Polymorphic Example </h1>
 
<h3> First Team Goal </h3>
 
<li> 
    {{ $goalFirstTeam->goal_body}}  
</li>

<h3> First Player Goal </h3>

<li> 
    {{ $goalFirstPlayer->goal_body}}  
</li>

<h3> Second Team Goal </h3>
 
<li> 
    {{ $goalSecondTeam->goal_body}}  
</li>
 
 
</body>
</html>
<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Player extends Model
{
    //
    public function goals()
    {
        return $this->morphOne(Goal::class, 'goalable');
    }
}

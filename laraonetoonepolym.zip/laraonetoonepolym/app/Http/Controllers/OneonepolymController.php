<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Team;
use App\Player;
use App\Goal;

class OneonepolymController extends Controller
{
    //
    public function oneonepolym()
    {
 
       $firstTeam = Team::find(1);
       $goalFirstTeam = $firstTeam->goals;
       //dd($goalFirstTeam->goal_body);	
 
       $firstPlayer = Player::find(1);
       $goalFirstPlayer = $firstPlayer->goals;
 
       $secondTeam = Team::find(2);
       $goalSecondTeam = $secondTeam->goals;
       
       return view('index',compact('goalFirstTeam','goalFirstPlayer','goalSecondTeam'));
    }
}
